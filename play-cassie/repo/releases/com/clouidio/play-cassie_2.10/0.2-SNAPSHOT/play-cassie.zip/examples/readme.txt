The examples directory
